// src/components/ProjectCard.js
import React from 'react';
import LazyLoad from 'react-lazyload'; // For lazy loading images
// import './Projects.css';

const ProjectCard = ({ project }) => {
  return (
    <div className="project-card">
      <LazyLoad height={200} offset={100}>
        <img src={project.image} alt={project.name} />
      </LazyLoad>
      <h3>{project.name}</h3>
      <p>{project.description}</p>
    </div>
  );
};

export default ProjectCard;
