// src/components/Contact.js
import React, { useState } from 'react';
import '../styles/Contact.css';

const Contact = () => {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission
    alert('Form Submitted!');
  };

  return (
    <div className="contact">
      <h2>Contact</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Your Name" onChange={handleChange} value={formData.name} required />
        <input type="email" name="email" placeholder="Your Email" onChange={handleChange} value={formData.email} required />
        <textarea name="message" placeholder="Your Message" onChange={handleChange} value={formData.message} required />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default Contact;
