// src/components/Contact.test.js
import { render, screen, fireEvent } from '@testing-library/react';
import Contact from './Contact';

test('renders Contact form', () => {
  render(<Contact />);
  const nameInput = screen.getByPlaceholderText(/Your Name/i);
  fireEvent.change(nameInput, { target: { value: 'John Doe' } });
  expect(nameInput.value).toBe('John Doe');
});
