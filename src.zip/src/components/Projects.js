// src/components/Projects.js
import React from 'react';
import ProjectCard from './ProjectCard';
import '../styles/Projects.css';

const projects = [
  { id: 1, name: "Project One", description: "A web application using React", image: require('../assets/images/download (1).jpg') },
  { id: 2, name: "Project Two", description: "A mobile app built with React Native", image: require('../assets/images/download.jpg') },
  // Add more projects if needed
];

const Projects = () => {
  return (
    <div className="projects">
      <h2>Projects</h2>
      <div className="project-cards">
        {projects.map(project => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>
    </div>
  );
};

export default Projects;
