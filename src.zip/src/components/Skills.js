// src/components/Skills.js
import React from 'react';
import '../styles/Skills.css';

const Skills = () => {
  return (
    <div className="skills">
      <h2>Skills</h2>
      <ul>
        <li>React</li>
        <li>JavaScript</li>
        <li>HTML/CSS</li>
        <li>Node.js</li>
        <li>Git</li>
        {/* Add more skills */}
      </ul>
    </div>
  );
};

export default Skills;
