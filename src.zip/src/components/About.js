// src/components/About.js
import React from 'react';
import '../styles/About.css';

const About = () => {
  return (
    <div className="about">
      <h2>About Me</h2>
      <p>
        Hi, I'm a passionate software developer with a focus on building efficient and user-friendly web applications. 
        I specialize in front-end development with React and have a solid understanding of back-end technologies like Node.js.
      </p>
      
      <p>
        With a degree in Computer Science, I enjoy solving problems and continuously learning new technologies to improve my skills. 
        I love creating clean, responsive websites and ensuring they deliver the best possible user experience.
      </p>
    </div>
  );
};

export default About;
