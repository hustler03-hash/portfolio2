// src/components/Resume.js
import React, { useState } from 'react';
import '../styles/Resume.css'; // Ensure that the CSS is imported

const Resume = () => {
  const [showMessage, setShowMessage] = useState(false);

  const handleDownload = () => {
    setShowMessage(true);
    setTimeout(() => {
      setShowMessage(false); // Hide the message after 3 seconds
    }, 3000);
  };

  return (
    <div className="resume">
      <div className="resume-container">
        <h2>Resume</h2>
        <p className="resume-description">
          Explore my career journey and accomplishments by downloading my full resume.
        </p>

        <div className="resume-actions">
          <a
            href="/resume.pdf"
            download
            onClick={handleDownload}
            className="download-btn"
          >
            Download Resume
          </a>
        </div>

        {showMessage && (
          <div className="popup-message">
            <p>Your resume is being downloaded!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Resume;
