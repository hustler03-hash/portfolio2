// src/App.js
import React from 'react';
import './styles/App.css';
import About from './components/About';
import Projects from './components/Projects';
import Skills from './components/Skills';
import Resume from './components/Resume';
import Contact from './components/Contact';

const App = () => {
  return (
    <div className="app">
      <header>
        <nav className="navbar">
          <h1>My Portfolio</h1>
          <ul className="nav-links">
            <li><a href="#about" className="nav-btn">About</a></li>
            <li><a href="#projects" className="nav-btn">Projects</a></li>
            <li><a href="#skills" className="nav-btn">Skills</a></li>
            <li><a href="#resume" className="nav-btn">Resume</a></li>
            <li><a href="#contact" className="nav-btn">Contact</a></li>
          </ul>
        </nav>
      </header>

      <main>
        <section id="about">
          <About />
        </section>

        <section id="projects">
          <Projects />
        </section>

        <section id="skills">
          <Skills />
        </section>

        <section id="resume">
          <Resume />
        </section>

        <section id="contact">
          <Contact />
        </section>
      </main>
    </div>
  );
};

export default App;
