// src/App.test.js

import { render, screen } from '@testing-library/react';
import App from './App';

test('renders portfolio header', () => {
  render(<App />);
  // Update this query to match the actual text in your app
  const headerElement = screen.getByText(/portfolio/i); // Change to a real text in your App
  expect(headerElement).toBeInTheDocument();
});
